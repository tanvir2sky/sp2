<div class="w3layouts-top-strip">
    <div class="top-srip-agileinfo">
        <div class="w3ls-social-icons text-left">
            <a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
            <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
            <a class="pinterest" href="#"><i class="fa fa-pinterest-p"></i></a>
            <a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a>

        </div>
        <div class="agileits-contact-info text-right">
            <ul>
                <li><i class="fa fa-volume-control-phone" aria-hidden="true"></i> +090 480 088</li>
                <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:info@example.com">mail@example.com</a></li>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div>
</div>