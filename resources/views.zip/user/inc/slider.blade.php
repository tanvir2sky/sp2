<div id="demo-1" data-zs-src='["user/images/4.jpg", "user/images/2.jpg", "user/images/1.jpg","user/images/3.jpg"]' data-zs-overlay="dots">
    <div class="demo-inner-content">
        <!--/header-w3l-->
        <div class="header-w3-agileits" id="home">
            <div class="inner-header-agile">
                <div class="w3ls_search">
                    <div class="cd-main-header">
                        <ul class="cd-header-buttons">
                            <li><a class="cd-search-trigger" href="#cd-search"> <span></span></a></li>
                        </ul> <!-- cd-header-buttons -->
                    </div>
                    <div id="cd-search" class="cd-search">
                        <form action="#" method="post">
                            <input name="Search" type="search" placeholder="Search...">
                        </form>
                    </div>
                </div>

            </div>


            <!--//header-w3l-->
            <!--/banner-info-->
            <div class="baner-info">
                <h3>Wel<span>Come </span>To   <span>Luxury </span> Hotel</h3>
                <h4>Book Your Dream Resort Destinations</h4>
                <p>Enjoy Your Stay In</p>
            </div>
            <!--/banner-ingo-->

        </div>
    </div>
</div>