<div class="guests-agile">
    <h3 class="tittle">Our Guests</h3>
    <div class="w3_agileits_testimonial_grids">
      <section class="slider">
        <div class="flexslider">
          <ul class="slides">
            <li>
              <div class="w3_agileits_testimonial_grid">
              <i class="fa fa-quote-right" aria-hidden="true"></i>
                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
                  dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                  proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                <img src="{{asset('user/images/admin.jpg')}}" alt=" " class="img-responsive" />

              </div>
            </li>
            <li>
              <div class="w3_agileits_testimonial_grid">
              <i class="fa fa-quote-right" aria-hidden="true"></i>
                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
                  dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                  proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                <img src="{{asset('user/images/admin2.jpg')}}" alt=" " class="img-responsive" />

              </div>
            </li>
            <li>
              <div class="w3_agileits_testimonial_grid">
              <i class="fa fa-quote-right" aria-hidden="true"></i>
                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
                  dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                  proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                <img src="{{asset('user/images/admin.jpg')}}" alt=" " class="img-responsive" />

              </div>
            </li>
          </ul>
        </div>
      </section>

      <!-- //flexSlider -->
    </div>
</div>
