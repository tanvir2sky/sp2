<div class="w3_content_agilleinfo_inner">
    <div class="container">
        <div class="inner-agile-w3l-part-head">
            <h2 class="w3l-inner-h-title">Contact</h2>

        </div>
        <div class="w3_mail_grids">
            <form action="#" method="post">
                <div class="col-md-6 w3_agile_mail_grid">
                    <input type="text" placeholder="Your Name" required="">
                    <input type="email" placeholder="Your Email" required="">
                    <input type="text" placeholder="Your Phone Number" required="">


                </div>
                <div class="col-md-6 w3_agile_mail_grid">
                    <textarea name="Message" placeholder="Your Message" required=""></textarea>
                    <input type="submit" value="Submit">
                </div>
                <div class="clearfix"> </div>
            </form>
        </div>
    </div>
    <div class=" map">
        <iframe src="https://www.google.com/maps/embed/v1/place?q=place_id:ChIJayb1_k_GVTcRDvCBOSQJaHM&key=AIzaSyB7cjbfTTHl2w_b9erMss1_orRBJiEeBIw"></iframe>
    </div>
</div>