<div class="special featured">
    <div class="container">
        <div class="ab-w3l-spa">
            <h3 class="tittle">Welcome to Our Resort!</h3>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. ever since the 1500s.Itaque earum rerum hic tenetur a sapiente delectus reiciendis maiores hasellusMaecenas ac hendrerit purus. Lorem ipsum dolor sit amet.Lorem Ipsum is simply dummy text of the printing and typesetting industry
            </p>
        </div>
        <!-- services -->
        <div class="w3_agileits_services_grids">
            <div class="col-md-3 w3_agileits_services_grid hvr-overline-from-center">
                <div class="w3_agileits_services_grid_agile">
                    <div class="w3_agileits_services_grid_1">
                        <img src="{{asset('user/images/5.jpg')}}" alt="service-img">
                    </div>
                    <h3>Deluxe Room</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                </div>
            </div>
            <div class="col-md-3 w3_agileits_services_grid hvr-overline-from-center">
                <div class="w3_agileits_services_grid_agile">
                    <div class="w3_agileits_services_grid_1">
                        <img src="{{asset('user/images/6.jpg')}}" alt="service-img">
                    </div>
                    <h3>Luxury Room</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                </div>
            </div>
            <div class="col-md-3 w3_agileits_services_grid hvr-overline-from-center">
                <div class="w3_agileits_services_grid_agile">
                    <div class="w3_agileits_services_grid_1">
                        <img src="{{asset('user/images/7.jpg')}}" alt="service-img">
                    </div>
                    <h3>Swimming Pool</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                </div>
            </div>
            <div class="col-md-3 w3_agileits_services_grid hvr-overline-from-center">
                <div class="w3_agileits_services_grid_agile">
                    <div class="w3_agileits_services_grid_1">
                        <img src="{{asset('user/images/8.jpg')}}" alt="service-img">
                    </div>
                    <h3>Spa Care</h3>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
        <!-- //services -->

        <div class="agileinf-button">    <a class="read" href="single.html">
                Read More
            </a>
        </div>

    </div>
</div>