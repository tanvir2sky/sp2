<div class="featured-facility">
    <!-- welcome -->

    <div class="spa-agile">
        <h3 class="tittle fea">Featured  Facilities</h3>
        <div class="col-md-3 spa-grid">

            <i class="fa fa-cutlery" aria-hidden="true"></i>

            <h4>Restaurant </h4>

        </div>
        <div class="col-md-3 spa-grid">

            <i class="fa fa-glass" aria-hidden="true"></i>


            <h4>Bar</h4>


        </div>
        <div class="col-md-3 spa-grid lost">

            <i class="fa fa-wheelchair-alt" aria-hidden="true"></i>

            <h4>Gym</h4>


        </div>
        <div class="col-md-3 spa-grid lost">

            <i class="fa fa-car" aria-hidden="true"></i>


            <h4>Pick Up</h4>


        </div>
        <div class="clearfix"> </div>
    </div>

    <!-- //welcome -->
</div>