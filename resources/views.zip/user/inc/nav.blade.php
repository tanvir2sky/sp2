<nav class="navbar navbar-default" style="background-color: lightslategrey">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <h1><a href="{{url('/')}}"><span>A</span>iub <p class="s-log">Hotel</p></a>

        </h1>
    </div>
    <!-- navbar-header -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

        <ul class="nav navbar-nav">
            <li class="{{ Request::path() =='/' ? 'active' : '' }}"><a href="{{url('/')}}">Home</a></li>
            <li class="{{ Request::path() =='about' ? 'active' : '' }}"><a href="{{url('/about')}}">About</a></li>
            <li class="{{ Request::path() =='gallery' ? 'active' : '' }}"><a href="{{url('/gallery')}}">Gallery</a></li>
            <li class="{{ Request::path() =='contact' ? 'active' : '' }}"><a href="{{url('/contact')}}">Contact</a></li>
        </ul>


    </div>
    <div class="clearfix"></div>
</nav>