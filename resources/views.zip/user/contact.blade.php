@extends('user.layouts.main')


@section('content')

    @include('user.inc.contact')

    @endsection