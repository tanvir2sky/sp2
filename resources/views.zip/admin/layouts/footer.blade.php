 <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.1
    </div>
    <strong>Copyright &copy; 2017 <a href="http://technoPLUSIT.com.au">technoPLUS IT</a> </strong> All rights
    reserved.
  </footer>